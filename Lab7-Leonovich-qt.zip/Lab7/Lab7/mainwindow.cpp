#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow) {
    ui->setupUi(this);
    connect(ui->button_add, SIGNAL(clicked()), this, SLOT(Add()));
    connect(ui->button_clear, SIGNAL(clicked()), this, SLOT(Clear()));
    connect(ui->button_to_right, SIGNAL(clicked()), this, SLOT(ToRight()));
    connect(ui->button_delete, SIGNAL(clicked()), this, SLOT(Delete()));
}

MainWindow::~MainWindow() {
    delete ui;
}

bool MainWindow::Contains(QListWidget *list, QString text) {
    return !list->findItems(text, Qt::MatchFlag::MatchExactly).empty();
}

void MainWindow::Add() {
    auto edit = ui->edit;
    auto text = edit->text();
    if (text.count(' ') == text.length())
        return;
    if (!Contains(ui->list_left, text)) {
        ui->list_left->addItem(text);
        edit->setText("");
    }
}

void MainWindow::Clear() {
    ui->list_left->clear();
    ui->list_right->clear();
}

void MainWindow::ToRight() {
    //QString selected = ui->list_left->selectedItems().first()->text();
    for (auto x: ui->list_left->selectedItems()){
        if (!Contains(ui->list_right, x->text())) {
            ui->list_right->addItem(x->text());
        }
    }
}

void MainWindow::Delete() {
    auto selected_left = ui->list_left->selectedItems();
    auto selected_right = ui->list_right->selectedItems();

    auto remove = [](QListWidget *list_widget, QList<QListWidgetItem *> list_selected) {
        foreach(QListWidgetItem * item, list_selected) {
            delete list_widget->takeItem(list_widget->row(item));
        }
    };

    remove(ui->list_left, selected_left);
    remove(ui->list_right, selected_right);
}
