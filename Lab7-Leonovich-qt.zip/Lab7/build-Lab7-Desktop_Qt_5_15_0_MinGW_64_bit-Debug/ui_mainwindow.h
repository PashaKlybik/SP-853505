/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.15.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QWidget *widget;
    QVBoxLayout *verticalLayout;
    QLineEdit *edit;
    QHBoxLayout *horizontalLayout_2;
    QListWidget *list_left;
    QListWidget *list_right;
    QHBoxLayout *horizontalLayout;
    QPushButton *button_add;
    QPushButton *button_clear;
    QPushButton *button_to_right;
    QPushButton *button_delete;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(800, 600);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        widget = new QWidget(centralwidget);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(20, 30, 761, 511));
        verticalLayout = new QVBoxLayout(widget);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        edit = new QLineEdit(widget);
        edit->setObjectName(QString::fromUtf8("edit"));

        verticalLayout->addWidget(edit);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        list_left = new QListWidget(widget);
        list_left->setObjectName(QString::fromUtf8("list_left"));

        horizontalLayout_2->addWidget(list_left);

        list_right = new QListWidget(widget);
        list_right->setObjectName(QString::fromUtf8("list_right"));

        horizontalLayout_2->addWidget(list_right);


        verticalLayout->addLayout(horizontalLayout_2);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        button_add = new QPushButton(widget);
        button_add->setObjectName(QString::fromUtf8("button_add"));

        horizontalLayout->addWidget(button_add);

        button_clear = new QPushButton(widget);
        button_clear->setObjectName(QString::fromUtf8("button_clear"));

        horizontalLayout->addWidget(button_clear);

        button_to_right = new QPushButton(widget);
        button_to_right->setObjectName(QString::fromUtf8("button_to_right"));

        horizontalLayout->addWidget(button_to_right);

        button_delete = new QPushButton(widget);
        button_delete->setObjectName(QString::fromUtf8("button_delete"));

        horizontalLayout->addWidget(button_delete);


        verticalLayout->addLayout(horizontalLayout);

        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 800, 21));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        button_add->setText(QCoreApplication::translate("MainWindow", "Add", nullptr));
        button_clear->setText(QCoreApplication::translate("MainWindow", "Clear", nullptr));
        button_to_right->setText(QCoreApplication::translate("MainWindow", "ToRight", nullptr));
        button_delete->setText(QCoreApplication::translate("MainWindow", "Delete", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
