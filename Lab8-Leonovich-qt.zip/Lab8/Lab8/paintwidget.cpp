#include "paintwidget.h"
#include <QPainter>
#include <QPen>

void drawTree(QPainter &painter) {
    painter.setPen(QPen(Qt::black, 1, Qt::SolidLine, Qt::FlatCap));
    painter.setBrush(QBrush(QColor(20, 225, 10), Qt::SolidPattern));
    QPolygon polygon;
    polygon << QPoint(180, 400) << QPoint(20, 400);
    polygon << QPoint(90, 350) << QPoint(40, 350);
    polygon << QPoint(90, 310) << QPoint(60, 310);
    polygon << QPoint(100, 270) << QPoint(140, 310);
    polygon << QPoint(110, 310) << QPoint(160, 350);
    polygon << QPoint(110, 350);

    painter.drawPolygon(polygon);
    painter.setBrush(QBrush(QColor(210, 105, 30), Qt::SolidPattern));
    painter.drawRect(80, 400, 40, 50);
}

void drawSun(QPainter &painter) {
    painter.setBrush(QBrush(QColor(255, 255, 0), Qt::SolidPattern));
    painter.drawEllipse(100, 100, 99, 102);
    painter.drawArc(300, 100, 70, 100, 100 * 16, 160 * 16);
    painter.drawArc(300, 100, 70, 100, -100 * 16, -160 * 16);
}

void drawBackground(QPainter &painter) {
    painter.setPen(QPen(Qt::black, 1, Qt::SolidLine, Qt::FlatCap));
    painter.setBrush(QBrush(QColor(0, 255, 255), Qt::SolidPattern));
    painter.drawRect(0, 0, 799, 300);
    painter.setBrush(QBrush(QColor(0, 255, 0), Qt::SolidPattern));
    painter.drawRect(0, 300, 799, 200);
}

PaintWidget::PaintWidget(QWidget *parent) : QWidget(parent) {}

void PaintWidget::SetDraw(bool draw) {
    _draw = draw;
    repaint();
}

void PaintWidget::paintEvent(QPaintEvent *) {
    if (!_draw)
        return;
    QPainter painter(this); // Создаём объект отрисовщика
    // Устанавливаем кисть абриса
    drawBackground(painter);
    drawSun(painter);
    drawTree(painter);
    painter.setBrush(QBrush(Qt::red, Qt::SolidPattern));
    painter.drawRect(300, 200, 200, 200);


}
