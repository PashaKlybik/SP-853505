#ifndef ENUMS_H
#define ENUMS_H

enum class Color {
    RED,
    GREEN,
    BLUE
};

enum class Primitive {
    RHOMB,
    SQUARE,
    CIRCLE,
    STAR
};

#endif // ENUMS_H
