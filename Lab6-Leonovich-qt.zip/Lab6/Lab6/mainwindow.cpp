#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <iostream>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow) {
    ui->setupUi(this);
    QCursor cursorTarget = QCursor(QPixmap(R"(d:\University\SP\Lab6\Lab6\icon.ico)"), 0, 0);
    this->setCursor(cursorTarget);
    text = ui->text;
    text_copy = ui->text_copy;
    connect(ui->actionStart, SIGNAL(triggered()), this, SLOT(onClickStart()));
    connect(ui->actionStop, SIGNAL(triggered()), this, SLOT(onClickStop()));

    timer = std::make_unique<QTimer>();
    timer->setInterval(10);
    connect(timer.get(), SIGNAL(timeout()), this, SLOT(moveText()));
}

MainWindow::~MainWindow() {
    delete ui;
}

void MainWindow::onClickStart() {
    timer->start();
}

void MainWindow::onClickStop() {
    timer->stop();
}

void MainWindow::moveText() {
    auto move = [](auto label) {
        auto geometry = label->geometry();
        if (geometry.x() < -geometry.width()) {
            geometry.setX(geometry.x() + 1800);
            geometry.setWidth(geometry.width() + 1800);
        } else {
            geometry.setX(geometry.x() - 1);
            geometry.setWidth(geometry.width() - 1);
        }
        label->setGeometry(geometry);
        label->updateGeometry();
    };

    move(text);
    move(text_copy);
}
