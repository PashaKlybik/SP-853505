#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow) {
    ui->setupUi(this);

    connect(ui->actionStart, SIGNAL(triggered()), this, SLOT(onClickStart()));
    connect(ui->actionStop, SIGNAL(triggered()), this, SLOT(onClickStop()));

    thread1 = new QTimer(this);
    thread2 = new QTimer(this);
    thread3 = new QTimer(this);

    thread1->setInterval(8);
    thread2->setInterval(16);
    thread3->setInterval(32);

    connect(thread1, SIGNAL(timeout()), this, SLOT(thread1Tick()));
    connect(thread2, SIGNAL(timeout()), this, SLOT(thread2Tick()));
    connect(thread3, SIGNAL(timeout()), this, SLOT(thread3Tick()));
}

MainWindow::~MainWindow() {
    delete ui;
}

void MainWindow::thread1Tick() {
    moveText(ui->thr1, ui->thr1_copy);
}

void MainWindow::thread2Tick() {
    moveText(ui->thr2, ui->thr2_copy);
}

void MainWindow::thread3Tick() {
    moveText(ui->thr3, ui->thr3_copy);
}

void MainWindow::onClickStart() {
    thread1->start();
    thread2->start();
    thread3->start();
}

void MainWindow::onClickStop() {
    thread1->stop();
    thread2->stop();
    thread3->stop();
}

void MainWindow::moveText(QLabel *l1, QLabel *l2) {
    auto move = [](auto label) {
        auto geometry = label->geometry();
        if (geometry.x() < -geometry.width()) {
            geometry.setX(geometry.x() + 1600);
            geometry.setWidth(geometry.width() + 1600);
        } else {
            geometry.setX(geometry.x() - 1);
            geometry.setWidth(geometry.width() - 1);
        }
        label->setGeometry(geometry);
        label->updateGeometry();
    };

    move(l1);
    move(l2);
}
