/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.13.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *actionStart;
    QAction *actionStop;
    QWidget *centralwidget;
    QLabel *thr1;
    QLabel *thr1_copy;
    QLabel *thr2;
    QLabel *thr2_copy;
    QLabel *thr3;
    QLabel *thr3_copy;
    QMenuBar *menubar;
    QMenu *menuMain;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(800, 600);
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(MainWindow->sizePolicy().hasHeightForWidth());
        MainWindow->setSizePolicy(sizePolicy);
        MainWindow->setMinimumSize(QSize(800, 600));
        MainWindow->setMaximumSize(QSize(800, 600));
        actionStart = new QAction(MainWindow);
        actionStart->setObjectName(QString::fromUtf8("actionStart"));
        actionStop = new QAction(MainWindow);
        actionStop->setObjectName(QString::fromUtf8("actionStop"));
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        thr1 = new QLabel(centralwidget);
        thr1->setObjectName(QString::fromUtf8("thr1"));
        thr1->setGeometry(QRect(345, 100, 110, 40));
        QFont font;
        font.setFamily(QString::fromUtf8("Times New Roman"));
        font.setPointSize(20);
        font.setBold(true);
        font.setWeight(75);
        thr1->setFont(font);
        thr1_copy = new QLabel(centralwidget);
        thr1_copy->setObjectName(QString::fromUtf8("thr1_copy"));
        thr1_copy->setGeometry(QRect(1145, 100, 110, 40));
        thr1_copy->setFont(font);
        thr2 = new QLabel(centralwidget);
        thr2->setObjectName(QString::fromUtf8("thr2"));
        thr2->setGeometry(QRect(345, 200, 110, 40));
        thr2->setFont(font);
        thr2_copy = new QLabel(centralwidget);
        thr2_copy->setObjectName(QString::fromUtf8("thr2_copy"));
        thr2_copy->setGeometry(QRect(1145, 200, 110, 40));
        thr2_copy->setFont(font);
        thr3 = new QLabel(centralwidget);
        thr3->setObjectName(QString::fromUtf8("thr3"));
        thr3->setGeometry(QRect(345, 300, 110, 40));
        thr3->setFont(font);
        thr3_copy = new QLabel(centralwidget);
        thr3_copy->setObjectName(QString::fromUtf8("thr3_copy"));
        thr3_copy->setGeometry(QRect(1145, 300, 110, 40));
        thr3_copy->setFont(font);
        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 800, 21));
        menuMain = new QMenu(menubar);
        menuMain->setObjectName(QString::fromUtf8("menuMain"));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindow->setStatusBar(statusbar);

        menubar->addAction(menuMain->menuAction());
        menuMain->addAction(actionStart);
        menuMain->addAction(actionStop);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        actionStart->setText(QCoreApplication::translate("MainWindow", "Start", nullptr));
        actionStop->setText(QCoreApplication::translate("MainWindow", "Stop", nullptr));
        thr1->setText(QCoreApplication::translate("MainWindow", "Thread 1", nullptr));
        thr1_copy->setText(QCoreApplication::translate("MainWindow", "Thread 1", nullptr));
        thr2->setText(QCoreApplication::translate("MainWindow", "Thread 2", nullptr));
        thr2_copy->setText(QCoreApplication::translate("MainWindow", "Thread 2", nullptr));
        thr3->setText(QCoreApplication::translate("MainWindow", "Thread 3", nullptr));
        thr3_copy->setText(QCoreApplication::translate("MainWindow", "Thread 3", nullptr));
        menuMain->setTitle(QCoreApplication::translate("MainWindow", "Main", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
