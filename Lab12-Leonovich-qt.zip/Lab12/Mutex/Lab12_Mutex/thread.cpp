#include "thread.h"

Thread::Thread(const QString &color, QMutex &mutex, QObject *parent)
    : QThread(parent),
      color(color),
      mutex(mutex) {

}

#include <QDebug>

void Thread::run() {
    while(!isInterruptionRequested()) {
        std::lock_guard lock(mutex);
        emit changeBackground(color);
        qDebug() << color;
        sleep(1);
    }
}
