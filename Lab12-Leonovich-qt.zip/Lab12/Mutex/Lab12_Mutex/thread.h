#ifndef WORKER_H
#define WORKER_H

#include <QObject>
#include <QThread>
#include <QMutex>

class Thread : public QThread
{
    Q_OBJECT
public:
    explicit Thread(const QString &color, QMutex &mutex, QObject *parent = nullptr);

    void run() override;

signals:
    void changeBackground(QString);

private:
    QString color;
    QMutex &mutex;
};

#endif // WORKER_H
