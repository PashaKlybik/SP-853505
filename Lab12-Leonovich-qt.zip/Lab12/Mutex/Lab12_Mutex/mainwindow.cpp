#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "thread.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    using namespace std::chrono_literals;

    ui->setupUi(this);

    thread1 = new Thread("red", mutex);
    thread2 = new Thread("green", mutex);
    thread3 = new Thread("blue", mutex);

    connect(thread1, SIGNAL(changeBackground(QString)), this, SLOT(changeBackground(QString)));
    connect(thread2, SIGNAL(changeBackground(QString)), this, SLOT(changeBackground(QString)));
    connect(thread3, SIGNAL(changeBackground(QString)), this, SLOT(changeBackground(QString)));

    thread1->start();
    thread2->start();
    thread3->start();
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::changeBackground(QString color) {
    this->setStyleSheet(QString("QMainWindow > QWidget { background-color: %1;}").arg(color));
}
